from django.contrib import admin
from techs.models import Tech

class TechAdmin(admin.ModelAdmin):
    fields = ['type','effect_name','effect_val']

admin.site.register(Tech, TechAdmin)
