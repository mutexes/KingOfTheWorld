from buildings.models import Building
from django.contrib import admin

class BuildingAdmin(admin.ModelAdmin):
    fields = ['type','effect_name','effect_val']

admin.site.register(Building, BuildingAdmin)
